<?php
    include_once("latihan04.php");

    TentangAplikasi();
    Cetaklabel01("Contoh Text");
    echo "<br>";
    Cetaklabel02("Ini Labelnya");
    echo "<br>";
    $ank1 = 5;
    $ank2 = 7;

    echo "Hasil Penjumlahan $ank1 dengan $ank2 adalah ". jumlahkan($ank1,$ank2);