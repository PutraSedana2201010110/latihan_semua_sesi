<?php
    //konfigurasi DBMS Mysql
    define ("DBHOST","localhost");
    define ("DBUSER","root");
    define ("DBPASS","");
    define ("DBNAME","db_mahasiswa");
    define ("DBPORT","3306");

    