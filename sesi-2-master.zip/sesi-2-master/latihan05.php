<?php

$nAwal = 0;
$nAkhir = 11;
do{
    echo "Perulangan ke-".$nAwal."<br>";
    $nAwal++;

}while($nAwal < $nAkhir);