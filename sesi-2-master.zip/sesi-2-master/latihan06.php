<?php

$nAwal = 0;
$nAkhir = 10;

for($cx = $nAwal; $cx < $nAkhir; $cx++){
    echo "Perulangan ke-".$cx."<br>";
}