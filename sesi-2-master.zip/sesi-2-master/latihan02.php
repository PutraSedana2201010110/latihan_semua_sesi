<?php
    $angka1 = 9;
    $angka2 = 9;

    if ($angka1 == $angka2){
        //bagian true
        echo "Nilai Variabel angka1 sama dengan variabel angka2";
    }else{
        //bagian false
        echo " Nilai variabel angka1 tidak sama dengan variabel angka2";
    }