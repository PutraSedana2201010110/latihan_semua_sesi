<?php
    $nAwal = 0;
    $nAkhir = 11;

    while($nAwal < $nAkhir){
        //blok yang diulang
        echo "🎭Perulangan🎭 ke-".$nAwal. "<br>";
        
        $nAwal++;
    }